﻿import { agentLensAuth } from "./auth.js";
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";

import {
  getSessions,
  getSession,
  stats,
  providers,
  events
} from "@agent-lens/core";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PUBLIC_DIR = path.resolve(
  __dirname,
  "../public"
);

function normalizeLimit(value: unknown): number {

  const raw = Number(value ?? 250);

  if (!Number.isFinite(raw)) {
    return 250;
  }

  return Math.min(
    Math.max(
      Math.floor(raw),
      1
    ),
    1000
  );
}

export function startServer(port = 4321) {

  const app = express();

app.disable("x-powered-by");

app.use(
  "/api",
  agentLensAuth()
);

app.use(
  express.json({
    limit: "1mb"
  })
);

  /*
   * ----------------------------------------------------------
   * OBSERVATORY FRONTEND
   * ----------------------------------------------------------
   */

  app.use(
    express.static(PUBLIC_DIR)
  );

  app.get("/", (_req, res) => {

    res.sendFile(
      path.join(
        PUBLIC_DIR,
        "index.html"
      )
    );
  });

  /*
   * ----------------------------------------------------------
   * HEALTH
   * ----------------------------------------------------------
   */

  app.get("/api/health", (_req, res) => {

    res.json({
      ok: true,
      service: "agent-lens",
      version: "MAX",
      dashboard: true,
      stream: true,
      timestamp: new Date().toISOString()
    });
  });

  /*
   * ----------------------------------------------------------
   * STATS
   * ----------------------------------------------------------
   */

  app.get("/api/stats", (_req, res) => {

    res.json(stats());
  });

  /*
   * ----------------------------------------------------------
   * PROVIDERS
   * ----------------------------------------------------------
   */

  app.get("/api/providers", (_req, res) => {

    res.json(providers());
  });

  /*
   * ----------------------------------------------------------
   * EVENTS
   * ----------------------------------------------------------
   */

  app.get("/api/events", (req, res) => {

    const limit =
      normalizeLimit(
        req.query.limit
      );

    res.json(
      events(limit)
    );
  });

  /*
   * ----------------------------------------------------------
   * SESSIONS
   * ----------------------------------------------------------
   */

  app.get("/api/sessions", (req, res) => {

    const limit =
      normalizeLimit(
        req.query.limit
      );

    res.json(
      getSessions(limit)
    );
  });

  app.get("/api/sessions/:id", (req, res) => {

    const session =
      getSession(
        req.params.id
      );

    if (!session) {

      res.status(404).json({
        error: "Session not found"
      });

      return;
    }

    res.json(session);
  });

  /*
   * ----------------------------------------------------------
   * SERVER-SENT EVENTS
   * ----------------------------------------------------------
   *
   * The stream polls the existing SQLite-backed event store.
   * No WebSocket dependency is required.
   */

  app.get("/api/stream", (req, res) => {

    res.setHeader(
      "Content-Type",
      "text/event-stream"
    );

    res.setHeader(
      "Cache-Control",
      "no-cache, no-transform"
    );

    res.setHeader(
      "Connection",
      "keep-alive"
    );

    res.setHeader(
      "X-Accel-Buffering",
      "no"
    );

    res.flushHeaders();

    let lastEventId = 0;

    try {

      const initial =
        events(1);

      if (
        initial.length &&
        typeof initial[0].id === "number"
      ) {
        lastEventId =
          initial[0].id;
      }

    } catch {
      lastEventId = 0;
    }

    res.write(
      `retry: 2000\n\n`
    );

    const sendEvents = () => {

      if (res.writableEnded) {
        return;
      }

      try {

        const current =
          events(100);

        const newEvents =
          current
            .filter(event =>
              typeof event.id === "number" &&
              event.id > lastEventId
            )
            .sort(
              (a, b) =>
                (a.id ?? 0) -
                (b.id ?? 0)
            );

        for (const event of newEvents) {

          if (
            typeof event.id === "number"
          ) {
            lastEventId = event.id;
          }

          res.write(
            `id: ${event.id ?? ""}\n`
          );

          res.write(
            `data: ${JSON.stringify(event)}\n\n`
          );
        }

      } catch (error) {

        console.error(
          "Agent Lens stream error:",
          error
        );
      }
    };

    const heartbeat =
      setInterval(() => {

        if (res.writableEnded) {

          clearInterval(heartbeat);
          return;
        }

        res.write(
          `: heartbeat ${Date.now()}\n\n`
        );

        sendEvents();

      }, 1000);

    req.on("close", () => {

      clearInterval(heartbeat);

      if (!res.writableEnded) {
        res.end();
      }

    });

    sendEvents();
  });

  /*
   * ----------------------------------------------------------
   * 404
   * ----------------------------------------------------------
   */

  app.use((_req, res) => {

    res.status(404).json({
      error: "Not found"
    });
  });

  /*
   * ----------------------------------------------------------
   * START
   * ----------------------------------------------------------
   */

  const server = app.listen(
    port,
    "127.0.0.1"
  );

  server.once(
    "error",
    (error: NodeJS.ErrnoException) => {

      if (error.code === "EADDRINUSE") {

        console.error("");
        console.error(
          `Agent Lens: port ${port} is already in use.`
        );

        console.error(
          `An Agent Lens server may already be running at http://127.0.0.1:${port}`
        );

        console.error("");
        return;
      }

      console.error(
        "Agent Lens server error:",
        error
      );
    }
  );

  server.once(
    "listening",
    () => {

      console.log("");
      console.log(
        "=================================================="
      );
      console.log(
        "          AGENT LENS MAX OBSERVATORY             "
      );
      console.log(
        "=================================================="
      );
      console.log("");

      console.log(
        `Dashboard: http://127.0.0.1:${port}`
      );

      console.log(
        `Health:    http://127.0.0.1:${port}/api/health`
      );

      console.log(
        `Stats:     http://127.0.0.1:${port}/api/stats`
      );

      console.log(
        `Providers: http://127.0.0.1:${port}/api/providers`
      );

      console.log(
        `Events:    http://127.0.0.1:${port}/api/events`
      );

      console.log(
        `Sessions:  http://127.0.0.1:${port}/api/sessions`
      );

      console.log(
        `Stream:    http://127.0.0.1:${port}/api/stream`
      );

      console.log("");
      console.log(
        "Observatory is online."
      );
      console.log(
        "Press Ctrl+C to stop."
      );
      console.log("");
    }
  );
  return server;
}




